package org.example;

import com.mongodb.*;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class Delete
{
    public static void main(String[] args)
    {
        MongoClient mc = new MongoClient();
        MongoDatabase mdb = mc.getDatabase("biblioteca");
        MongoCollection mco = mdb.getCollection("libros");

        //BORRADO INDIVIDUAL
        mco.deleteMany(new Document("name","2001, Odisea en el espacio"));
        //BORRADO PLURAL
        //mco.deleteMany(new Document("price","$gt", 50));
        mc.close();
    }
}
