package org.example;

import com.mongodb.*;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import java.util.ArrayList;
import java.util.List;

public class Insert
{
    public static void main(String[] args)
    {
        MongoClient mc = new MongoClient();
        MongoDatabase mdb = mc.getDatabase("biblioteca");
        MongoCollection mco = mdb.getCollection("libros");

        //INSERCIONES INDIVIDUALES
        Libro l1 = new Libro(5,"2001, Odisea en el espacio", 15);
        Libro l2 = new Libro(6,"Dune", 12);
        Document d1 = new Document("_id", l1.get_id()).append("name",l1.getName()).append("price",l1.getPrice());
        Document d2 = new Document("_id", l2.get_id()).append("name", l2.getName()).append("price", l2.getPrice());

        mco.insertOne(d1);
        mco.insertOne(d2);

        //INSERCIÓN MÚLTIPLE
        Libro l3 = new Libro(7,"La parte oscura del bosque", 18);
        Libro l4 = new Libro(8,"El legado robado", 22);
        List<Document> ListaLibros = new ArrayList<Document>();
        Document d3 = new Document("_id",l3.get_id()).append("name",l3.getName()).append("price",l3.getPrice());
        Document d4 = new Document("_id",l4.get_id()).append("name",l4.getName()).append("price",l4.getPrice());

        ListaLibros.add(d3);
        ListaLibros.add(d4);
        mco.insertMany(ListaLibros);
        mc.close();
    }

}
