package org.example;

public class Libro
{
    //ATRIBUTOS
    private int _id;
    private String name;
    private double price;

    //CONSTRUCTORES
    public Libro(int _id, String name, double price) {
        this._id = _id;
        this.name = name;
        this.price = price;
    }
    public Libro() {
    }

    //SETTERS
    public void set_id(int _id) {
        this._id = _id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    //GETTERS
    public int get_id() {
        return _id;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    //MÉTODOS
    @Override
    public String toString() {
        return "Libro{" +
                "_id=" + _id +
                ", name='" + name + '\'' +
                ", price=" + price +
                '}';
    }
}
