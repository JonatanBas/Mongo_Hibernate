package org.example;

import com.mongodb.*;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

public class Show
{
    public static void main(String[] args)
    {
        MongoClient mc = new MongoClient();
        MongoDatabase mdb = mc.getDatabase("biblioteca");
        MongoCollection mco = mdb.getCollection("libros");

        FindIterable fit = mco.find();
        MongoCursor<Libro> cursor = fit.iterator();

        while(cursor.hasNext())
            System.out.println(cursor.next());

        mc.close();
    }

}

