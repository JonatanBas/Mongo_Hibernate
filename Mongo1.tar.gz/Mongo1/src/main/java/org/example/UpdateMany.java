package org.example;

import com.mongodb.*;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class UpdateMany
{
    public static void main(String[] args)
    {
        MongoClient mc = new MongoClient();
        MongoDatabase mdb = mc.getDatabase("biblioteca");
        MongoCollection mco = mdb.getCollection("libros");

        Document base = new Document();
        Document updt = new Document("$inc",new Document("price", 35));
        mco.updateMany(base,updt);
        mc.close();
    }

}
