package org.example;

import jakarta.persistence.*;

import java.util.List;
@Entity
@Table(name = "alumnos")
public class Alumno
{
    //ATRIBUTOS
    @Id
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    private Long id;
    @Column
    private String nombre;
    @Column
    private int edad;
    @ManyToMany(mappedBy = "listaAlumnos")
    protected List<Profesor> listaProfesores;


    //CONSTRUCTORES
    public Alumno(Long id, String nombre, int edad, List<Profesor> listaProfesores) {
        this.id = id;
        this.nombre = nombre;
        this.edad = edad;
        this.listaProfesores = listaProfesores;
    }

    public Alumno() {
    }

    //SETTERS
    /*public void setId(Long id) {
        this.id = id;
    }*/

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setListaProfesores(List<Profesor> listaProfesores) {
        this.listaProfesores = listaProfesores;
    }

    //GETTERS
    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public List<Profesor> getListaProfesores() {
        return listaProfesores;
    }

    //TOSTRING

    @Override
    public String toString() {
        return "Alumno{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", edad=" + edad +
                ", ListaProfesores=" + listaProfesores +
                '}';
    }
}
