package org.example;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import java.util.*;


public class App 
{
    public static void main( String[] args )
    {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session ss = sf.openSession();
        Transaction tr = ss.beginTransaction();

        List<Alumno> listaAlumnos = new ArrayList<>();
        List<Profesor> listaProfesores = new ArrayList<>();

        Profesor p1 = new Profesor(1L,"Miguel",1800, null);
        Profesor p2 = new Profesor(2L, "Raul", 1700,null);

        Alumno a1 = new Alumno(3L,"Alfonso", 27,null);
        Alumno a2 = new Alumno(4L,"Daniel",31,null);

        listaAlumnos.add(a1);
        listaAlumnos.add(a2);
        listaProfesores.add(p1);
        listaProfesores.add(p2);


        p1.setListaAlumnos(listaAlumnos);
        p2.setListaAlumnos(listaAlumnos);
        a1.setListaProfesores(listaProfesores);
        a2.setListaProfesores(listaProfesores);

        //ss.persist(a1);
        //ss.persist(a2);
        ss.persist(p1);
        ss.persist(p2);

        tr.commit();
    }
}
