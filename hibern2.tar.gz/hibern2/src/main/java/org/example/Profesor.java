package org.example;
import jakarta.persistence.*;
import java.io.Serializable;
import java.util.*;

@Entity
@Table(name = "profesores")
public class Profesor implements Serializable
{
    //ATRIBUTOS
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column
    private String nombre;
    @Column
    private double salario;
    @ManyToMany(cascade = CascadeType.PERSIST)
    @JoinTable(name = "ProfesoresAlumnos",
                        joinColumns =
                        @JoinColumn(name = "ProfesoresIDs", referencedColumnName = "id"),

                        inverseJoinColumns =
                        @JoinColumn(name = "AlumnosIDs", referencedColumnName = "id")

                            )
    protected List<Alumno> listaAlumnos;

    //CONSTRUCTORES

    public Profesor(Long id, String nombre, double salario, List<Alumno> listaAlumnos) {
        this.id = id;
        this.nombre = nombre;
        this.salario = salario;
        listaAlumnos = listaAlumnos;
    }

    public Profesor() {
    }

    //SETTERS
    /*public void setId(Long id) {
        this.id = id;
    }*/

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setSalario(double salario){
        this.salario = salario;
    }

    public void setListaAlumnos(List<Alumno> listaAlumnos) {
        listaAlumnos = listaAlumnos;
    }

    //GETTERS
    public Long getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public double getSalario() {
        return salario;
    }

    public List<Alumno> getListaAlumnos() {
        return listaAlumnos;
    }

    //TOSTRING
    @Override
    public String toString() {
        return "Profesor{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", salario=" + salario +
                ", ListaAlumnos=" + listaAlumnos +
                '}';
    }
}
