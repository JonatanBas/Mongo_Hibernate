package org.example;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.io.Serializable;
@Entity
@Table(name = "Ordenadores")
public class Ordenador implements Serializable
{
    //ATRIBUTOS
    @Id
    private long id;
    @Column
    private String name;
    @Column
    private double price;

    //CONSTRUCTORES
    public Ordenador(long id, String name, double price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }
    public Ordenador() {

    }

    //SETTERS
    /*public void setId(long id) {
        this.id = id;
    }*/

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    //GETTERS
    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    //MÉTODOS
    @Override
    public String toString() {
        return "Ordenador{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", price=" + price +
                '}';
    }
}
