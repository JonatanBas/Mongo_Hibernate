package org.example;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.io.Serializable;
@Entity
@Table(name = "Usuarios")
public class Usuario implements Serializable
{
    //ATRIBUTOS
    @Id
    private long ID;
    @Column
    private String name;
    @Column
    private int age;
    @Column
    private double weight;

    //CONSTRUCTORES
    public Usuario(long ID, String name, int age, double weight) {
        this.ID = ID;
        this.name = name;
        this.age = age;
        this.weight = weight;
    }

    public Usuario() {
    }

    //SETTERS
    /*public void setId(long id) {
        this.id = id;
    }*/

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    //GETTERS
    public long getID() {
        return ID;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public double getWeight() {
        return weight;
    }

    //MÉTODOS
    @Override
    public String toString() {
        return "Usuario{" +
                "id=" + ID +
                ", name='" + name + '\'' +
                ", age=" + age +
                ", weight=" + weight +
                '}';
    }


}
